# Omakase Player

Omakase Player is an open source JavaScript player for building frame accurate video experiences.

[Omakase Player](https://api.player.byomakase.org/interfaces/OmakasePlayerApi.html) is constructed from the following main components:

- [Track Repository](https://api.player.byomakase.org/interfaces/OmakaseTrackApi.html) as central place containing all the media used in Omakase Player and its components
- [Media Player](https://api.player.byomakase.org/interfaces/PlayerApi.html) as Main and Sidecar media player
- [Chroming](https://api.player.byomakase.org/interfaces/ChromingApi.html) as Omakase Player user interface, visualization and control surface
- [Timeline](https://api.player.byomakase.org/interfaces/TimelineApi.html) as Multi-track timeline with unlimited depth for timed media visualization and control
- [Marker List Component](https://api.player.byomakase.org/interfaces/MarkerListApi.html) as Segments visualization and control surface organized into cut-lists
- [Tools](https://api.player.byomakase.org/interfaces/OmakaseToolsApi.html) and [Alerts](https://api.player.byomakase.org/interfaces/AlertsApi.html) as helpers for various general utils and interaction with end users with alerts
- [VU Meter](https://api.player.byomakase.org/interfaces/VuMeterApi.html) as Volume levels visualization tool
- [Control Bar](https://api.player.byomakase.org/interfaces/ControlBarApi.html) as a control surface that is detached from the Player Component

> For versions prior to v1.0.0 please refer to [v0.25.4 API documentation](https://api.player.byomakase.org/archive/0.25.4/index.html)

## Prerequisites

Omakase Player can be loaded as ES6 module inside HTML page. If loaded as ES6 module it requires hls.js loaded before Omakase Player:

```html
<script type="importmap">
  {
    "imports": {
      "hls.js": "https://cdn.jsdelivr.net/npm/hls.js@latest/dist/hls.mjs",
      "@omakase-player": "https://cdn.jsdelivr.net/npm/@byomakase/omakase-player@latest/dist/omakase-player.es.min.js"
    }
  }
</script>
```

Later on use regular object imports in JavaScript code.

```javascript
import {OmakasePlayer} from '@omakase-player';
let omakasePlayer = new OmakasePlayer();
```

Omakase Player can be used as ES module in TypeScript projects as follows.

If used with modern Typescript / Javascript frameworks (such as Angular, React or Vue), it is recommended to simply install Omakase Player as dependency into `package.json`:

```bash
npm install @byomakase/omakase-player
```

For a local tarball, run `npm run build && npm pack` in this repository, then
install the resulting archive in the consuming project. The package's `types`
entry points to `dist/index.d.ts`; keep that declaration entry and its referenced
declarations in the archive alongside `dist/omakase-player.es.js`.

The build bundles browser polyfills for `events`, `stream`, and `util`, including
the `EventEmitter` used by the subtitle converter. These must be resolved while
building the player; consumer aliases cannot repair an already-bundled empty
Node module stub. Run `npm run test:bundle` after building to smoke-test the
generated module in a DOM environment before packing it.

Optionally, you can include default Omakase Player CSS stylesheet or import and use `omakase-player.scss` SCSS stylesheet.

```html
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@byomakase/omakase-player@latest/dist/style.min.css" />
```

Stylesheet references default player overlay icons, help menu icons and default styles for video safe zones. All of which can be overridden.

## Player Initialization

Omakase Player requires div as a placeholder for HTML5 player.

```html
<div id="omakase-player"></div>
```

Initialize the player by providing div id in player configuration. If used as UMD module, Omakase Player objects are available in global `omakase` namespace:

```javascript
// Create new OmakasePlayer instance
let omakasePlayer = new omakase.OmakasePlayer({
  playerHtmlElementId: 'omakase-player',
});
```

Once player is initialized we can load main media by providing URL:

```javascript
omakasePlayer.loadMainMedia('https://my-server.com/myvideo.m3u8').subscribe({
  next: (mainMedia) => {
    console.log(`Main media loaded. Duration: ${mainMedia.duration}`);
  },
});
```

### MPEG-DASH (VOD)

Run the local sample from the repository root:

```bash
npm ci
npm run dev:dash
```

Open http://localhost:5173/demo/dash.html. The sample imports the local source and automatically loads a video-only manifest referencing two renditions of the public Envivio DASH stream; press Play once ready. This also works in browsers without AAC support. Paste another MPD URL and click **Load stream**, or pass it as the URL-encoded `url` query parameter. For audio/video playback in an AAC-capable browser, use `https://dash.akamaized.net/envivio/EnvivioDash3/manifest.mpd`.

Static MPEG-DASH MPDs are bridged to HLS playlists and played by the existing hls.js engine, without transcoding or adding dash.js. `.mpd` URLs are detected automatically; for URLs without an extension, specify the media type:

```javascript
import {MainMediaType} from '@omakase-player';

omakasePlayer.loadMainMedia('https://my-server.com/manifest.mpd', {
  mainMediaType: MainMediaType.DASH,
}).subscribe({
  next: (mainMedia) => console.log(mainMedia.duration),
  error: (error) => console.error(error),
});
```

Supported: one static MPD containing one or more contiguous Periods and separate fragmented MP4 video/audio. Period starts/durations are inferred from explicit timing, adjacent Periods, and `mediaPresentationDuration`. Nonzero first Period starts are normalized to playback time zero; duration and sidecar timelines use that normalized axis. Pre-authored content/ad/content Periods play through one HLS session, with discontinuities and new initialization maps at boundaries; seeking works across those boundaries. No additional MPD or ad-decision service is needed. Period tracks must retain compatible codec strings, declared video frame rates and audio channel/sample-rate layouts. Audio tracks are matched by language, Role and Label, with representation IDs disambiguating otherwise identical tracks. Video variants match by codec and representation ID, falling back to nearest bandwidth when an ad has a different rendition ladder. All video variants within each Period must have aligned segment boundaries.

Segment addressing supports inherited `BaseURL`, `SegmentTemplate`, `SegmentList` and `SegmentBase`, with a lower-level addressing type overriding a different inherited type. Templates support duration or `SegmentTimeline` addressing (including repeats), `startNumber`/inclusive `endNumber`, `$RepresentationID$`, `$Bandwidth$`, `$Number$`, `$Time$`, initialization elements/ranges, and per-segment index templates/ranges. SegmentList supports explicit media URLs/ranges, initialization, duration/timeline timing, and per-segment index URLs/ranges. SegmentBase supports `indexRange`, external `RepresentationIndex` resources/ranges, and SIDX versions 0/1 including hierarchical references. Indexes are resolved to HLS media byte ranges when hls.js first requests a rendition's playlist: the initial video and audio renditions are resolved while the load starts (their errors fail the load), other ladder renditions only when the player switches to them. Missing initialization/index information can be discovered from top-level MP4 boxes, usually with a single 16 KiB request. Unindexed fragmented files can be used as one segment when their media portion is at most 64 MiB and the server exposes the file size; larger files need explicit segment addressing or SIDX. Progressive (non-fragmented) MP4 is not supported by this bridge.

Servers may return `206 Partial Content` or ignore `Range` and return a full-file `200 OK`: the default index and byte-range fragment loaders stream past and discard the prefix, retain only the requested bytes, and cancel the remaining response. The whole media file is not buffered unless it is explicitly addressed as one media segment. Without server range support, each fragment or seek may still require downloading the prefix again, so HTTP range support is strongly recommended for large media. Servers must allow CORS access to the MPD, indexes, initialization segments, and media segments. Alternate audio AdaptationSets become selectable HLS audio tracks; the highest-bandwidth representation is used within each audio AdaptationSet. Playback requires browser codec support.

MPD text AdaptationSets support standalone or segmented WebVTT (`text/vtt`), TTML/IMSC (`application/ttml+xml`), and fragmented MP4 `wvtt`/`stpp` (`application/mp4`). Text tracks retain language, labels, caption/subtitle roles and `main` defaults; forced-subtitle roles are exposed as `customAttrs.dashForced` rather than automatically enabled. A single unsegmented WebVTT or TTML file that needs no time shift becomes an ordinary text track referencing its URL, fetched by the text renderer when used. Other text (segmented, byte-ranged, shifted or fragmented MP4) is downloaded and normalized using Period starts and presentation offsets, including WebVTT timestamp maps. WebVTT markup, cue settings, STYLE and REGION blocks are preserved. TTML/stpp retains document styling/regions through the IMSC renderer by default; explicitly selecting a WebVTT/native handler uses a plain-text normalized export instead. Auxiliary tracks may have sparse timelines, appear/disappear between Periods, and be clipped at Period boundaries independently of A/V.

Image AdaptationSets support JPEG, PNG, WebP and AVIF (subject to browser decoding), either as individual images or DASH-IF `http://dashif.org/guidelines/thumbnail_tile` sprite grids. Sheet dimensions must be declared and divisible by the tile grid. Tiles use row-major order and equal subdivisions of the untrimmed segment duration. Image tracks become ordinary thumbnail tracks with generated WebVTT/`xywh` sources that reference the images by URL (only byte-range sprites, which no URL can address, are downloaded): select their source with the existing `chroming.setThumbnailTrack` API (pass `fileFormatType: FileFormatType.VTT` for the generated Blob URL) or use them in timeline thumbnail lanes. They are not automatically selected as the chroming thumbnail source. Text and image resources are authenticated with `AuthConfig` and support media byte ranges. Downloaded text is loaded alongside A/V startup, and auxiliary tracks are added before the load completes; the highest-bandwidth representation is selected within each auxiliary AdaptationSet.

Live/dynamic MPDs, multiple video AdaptationSets per Period, DRM, multiple `BaseURL` alternatives, XLink, Period gaps/overlaps, A/V SegmentTimeline gaps/overlaps, and A/V leading trims are rejected with an explicit load error. In-video CEA-608/708 captions are not extracted. A finite duration must be derivable for every Period. Audio/video tracks within each Period must share the same playback origin. A/V SegmentTemplate/List tracks must start at their `presentationTimeOffset`; SegmentBase/SIDX tracks may have a later first presentation timestamp due to composition offsets (such as B-frames), with playback timing derived by hls.js from the actual MP4 timestamps. A/V SIDX timestamps before `presentationTimeOffset` still require unsupported leading trims. General A/V leading-gap compensation is not implemented. Audio/video in the final Period may end before the presentation end the MPD declares, which encoders commonly do by a frame or two. Such tracks are played to their real end and the player raises a warning alert (also logged to the console) when the media loads. If every track ends early, the player's duration becomes where the media really ends, so playback, seeking to the end and the timeline stop there; if only some do, the duration is kept and a short video track holds its last frame (a short audio track is silent) until the end. At an intermediate Period boundary tracks must still reach the boundary: AAC-LC (`mp4a.40.2`) SIDX audio may end up to one 1024-sample frame short when `audioSamplingRate` is declared, and the final audio playlist duration accounts for that shortfall to keep the next Period aligned; audio samples are not padded or stretched. Alternate audio tracks must use the same codec.

Resource limits: 100,000 template/list segments per representation; 16 MiB per index request and discovered initialization prefix; 64 MiB aggregate index bytes, 2,048 index/discovery requests and 100,000 indexed media references per load; eight nested SIDX levels; 1,024 top-level boxes per discovery scan. Downloaded auxiliary resources have limits of 32 MiB per request, 128 MiB aggregate downloads, 4,096 requests and 100,000 cues per MPD load; sprite grids are limited to 10,000 tiles. Invalid ranges, inconsistent nested-index timing and ambiguous/incompatible Period track transitions fail explicitly.

DASH uses `playerControllerConfig[MainMediaType.DASH].hlsConfig` on `OmakasePlayer` (`controllerConfig` on `Player`) and `player.getPlaybackEngine(MainMediaType.DASH)` for HLS engine configuration/access. Authentication uses the existing `AuthConfig`; session state retains the original MPD URL. The MPD is fetched and bridged once, by the media's session in the window that loaded it, and kept for the life of the media: player reloads and re-attaching reuse it, and a detached window plays the same playlists, asking the owning window to build any it has not yet built instead of fetching the MPD and indexes again. Registered auxiliary tracks own their generated resources, retain them across controller destruction/detachment, and revoke them when the tracks are removed. A failed or cancelled load releases resources that have not been handed to the track repository.

Byte-range fragments of every HLS source, including DASH-derived and `EXT-X-BYTERANGE` playlists, are protected against servers that ignore `Range`. With the default loaders they are streamed with the Fetch loader, which applies `AuthConfig` headers through `hlsConfig.fetchSetup`; use `fetchSetup` to customize them, for example to enable cross-origin credentials. If an application sets `hlsConfig.xhrSetup` but not `fetchSetup`, ranged fragments keep using XHR so that its setup still applies, and a full-file response is buffered before being sliced. Non-range fragments retain the configured loader. Explicit custom `loader`/`fLoader` implementations are preserved and remain responsible for their own transport buffering; their completed HTTP 200 responses are sliced before being passed to hls.js, but a custom loader that buffers whole files can still exhaust memory.

#### Remaining DASH implementation gaps

This is a static DASH-to-HLS bridge, not a complete DASH client. The following inventory covers the current parser and playback integration; it is not an ISO/IEC 23009-1 conformance claim. Ordinary playback, seeking, buffering, and video ABR are provided by hls.js and are not missing features.

| Area | Missing or restricted support |
| --- | --- |
| Live and low latency | Dynamic MPDs, manifest refresh/patching, live DVR windows, `UTCTiming`, DASH availability timing, `ServiceDescription`, live-edge synchronization/catch-up, low-latency CMAF chunk addressing, and dynamic-to-static transitions. |
| Periods and splicing | Codec or declared video frame-rate changes, audio channel/sample-rate layout changes, adding/removing audio/video tracks, ambiguous alternate-track identities, and gaps/overlaps between Periods. Contiguous compatible Periods, timestamp resets, initialization changes, cross-Period seeks and pre-authored ad Periods are supported. External ad decisions, additional ad MPDs and event-driven source insertion are outside the single-MPD implementation. |
| Segment addressing | Low-latency/chunked `$SubNumber$` and `SegmentTimeline S@k` addressing. Implicit unindexed files are limited to fragmented MP4 with known file size and at most 64 MiB of media; progressive MP4 requires the separate MP4 playback path. Explicit lists, bounded templates, external/nested indexes and inherited addressing-type overrides are supported. |
| Timing flexibility | Leading presentation trims/gaps, timeline gaps/overlaps, differing audio/video presentation origins, unaligned video segment boundaries, unknown duration, and integer timing values beyond JavaScript safe precision. Template expansion is limited to 100,000 segments per representation; SIDX indexes to 16 MiB. |
| Containers and multiplexing | A/V requires separate `video/mp4` and `audio/mp4` representations. WebM, MPEG-TS, multiplexed A/V representations, `ContentComponent`, and `SubRepresentation` are rejected. A/V MIME type and a single codec must be declared; other codecs still depend on browser/hls.js support. Separate MP4 `wvtt`/`stpp`, raw text and image tracks are supported. |
| Protection | All MPD `ContentProtection` is rejected: no DASH CENC/CBCS signaling, PSSH/default-KID translation, DRM license integration, or key rotation through this bridge. HLS DRM configuration alone does not enable DASH DRM. |
| Text and images | WebVTT, TTML/IMSC, MP4 `wvtt`/`stpp`, and individual/tiled image thumbnail adaptations are mapped. Remaining restrictions: in-video CEA-608/708 extraction, encrypted text, subtitle MP4 edit lists/multiple sample descriptions, auxiliary codec changes between Periods, automatic forced-subtitle policy, external TTML image/font resources, raw text/image SegmentBase indexes, and trick-mode/I-frame representations. Auxiliary downloads are finite/eager rather than adaptive/on-demand. |
| Video selection | More than one video AdaptationSet, alternate camera/view selection, adaptation-set switching, codec-family alternatives/capability filtering, and tiled/spatial/scalable-video relationships are not implemented. Unsupported adaptations are rejected rather than filtered out. |
| Audio selection | No per-track audio bitrate adaptation: only the highest-bandwidth representation is retained. Alternate tracks must share a codec. DASH role/accessibility/default-selection semantics and additional channel-configuration schemes are not translated. |
| URL resolution and delivery | Multiple BaseURL alternatives, CDN failover/service-location selection, DASH Content Steering, `BaseURL@byteRange`, XLink, `xml:base`, MPD `Location`/`PatchLocation`, DASH URL-query descriptors, and non-HTTP(S) media URLs. |
| Descriptor metadata | `EssentialProperty` is rejected. `SupplementalProperty`, `Role`, `Accessibility`, and other DASH descriptors are not generally interpreted or preserved in generated playlists, including HDR/color and immersive-media signaling. |
| Events and interactivity | MPD `EventStream`, DASH `InbandEventStream` subscriptions, SCTE-35/DASH event-driven ad signaling, and DASH-specific event scheduling are not bridged. Raw in-band metadata exposed independently by hls.js is not equivalent to DASH event support. |
| DASH-specific policies and reporting | MPD buffer/playout policy hints, DASH-native ABR rules/metrics, DASH-derived CMCD/CMSD and reporting descriptors, offline MPD download/license management, and DASH MPD URL-fragment start-time semantics are not implemented. General HLS engine settings and player APIs remain available. |

For comparison with a full DASH client, see the [DASH-IF dash.js feature documentation](https://dashif.org/dash.js/pages/usage/).

### Player Chroming

Player chroming can be configured with the `chromingTheme`, `chromingThemeConfig`, `chromingWatermark`, `chromingWatermarkVisibility`, `chromingFullscreenChroming`, and `chromingStyleUrl` properties. These allow selection of a chroming theme, watermark, and other theme-specific configuration. Some code examples are shown below:

```javascript
let omakasePlayer = new OmakasePlayer({
  chromingTheme: ChromingTheme.DEFAULT,
  chromingWatermark: 'DEMO_SAMPLE',
  chromingThemeConfig: {
    controlBarVisibility: ControlBarVisibility.ENABLED,
    controlBar: [DefaultThemeControl.PLAY, DefaultThemeControl.SCRUBBER, DefaultThemeControl.VOLUME, DefaultThemeControl.TRACK_SELECTOR, DefaultThemeControl.FULLSCREEN_TOGGLE],
    trackSelectorAutoClose: false,
  },
});

let omakasePlayer = new OmakasePlayer({
  chromingTheme: ChromingTheme.DEFAULT,
  chromingThemeConfig: {
    controlBarVisibility: ControlBarVisibility.DISABLED,
    floatingControls: [DefaultThemeFloatingControl.PLAYBACK_CONTROLS],
  },
});

let omakasePlayer = new OmakasePlayer({
  chromingTheme: ChromingTheme.CHROMELESS,
});

/*  Custom template js  */
let omakasePlayer = new OmakasePlayer({
  chromingTheme: ChromingTheme.CUSTOM,
  chromingThemeConfig: {
    htmlTemplateId: 'custom-template',
  },
});

/** Custom template HTML 
<template id="custom-template">
  <media-control-bar>
    <omakase-marker-bars></omakase-marker-bars>
    <omakase-time-range></omakase-time-range>
  </media-control-bar>
</template>
*/
```

More information about Player Chroming customization and specific theme configurations is available in [Player Chroming](https://api.player.byomakase.org/documents/ChromingApi.README.html) manual.

Strings rendered by the player and its chroming (such as the live indicator button text) can be localized with the `localization` property. It is read-only — set once at construction and not changeable afterwards. Only known keys are accepted; any other key is ignored, and any key left unset falls back to its default value.

```javascript
let omakasePlayer = new OmakasePlayer({
  chromingTheme: ChromingTheme.OMAKASE,
  localization: {
    live: 'We are live!',
  },
});
```

## Player API

Complete list of Player API methods is available in API Reference Docs

### Playback control

Playback control is achieved through Player API.

```javascript
// plays video
omakasePlayer.player.play();

// plays video and notifies user on successful play action
omakasePlayer.player.play().subscribe(() => {
  console.log(`Play started`);
});

// pauses video
omakasePlayer.player.pause();

// seeks to timestamp
omakasePlayer.player.seekTo(123.45).subscribe({
  next: (result) => {
    if (result) {
      console.log(`Seek to timestamp success`);
    }
  },
});

// seeks to frame
omakasePlayer.video.seekTo(123, omakase.MediaTemporalFormat.FRAME_COUNT).subscribe({
  next: (result) => {
    if (result) {
      console.log(`Seek to frame success`);
    }
  },
});
```

### Events

Before or after loading media, we can observe various events. All events are emitted through the joint `onEvent$` observable

```javascript
// Subscribe to Observable
omakasePlayer.player.onEvent$.subscribe({
  next: (event) => {
    if (event.type === omakase.PlayerEventType.PLAYER_MAIN_MEDIA_LOADED) {
      let mainMediaState = event.data.mainMediaState;
      console.log(`Media loaded. Duration: ${mainMediaState.duration}`);
    }
  },
});
```

Video playback events subscription examples:

```javascript
omakasePlayer.player.onEvent$.pipe(rxjs.filter((event) => event.type === omakase.PlayerEventType.PLAYER_PLAY)).subscribe({
  next: (event) => {
    console.log(`Media play. Timestamp: ${event.data.currentTime}`);
  },
});

omakasePlayer.player.onEvent$.pipe(rxjs.filter((event) => event.type === omakase.PlayerEventType.PLAYER_PAUSE)).subscribe({
  next: (event) => {
    console.log(`Media pause. Timestamp: ${event.data.currentTime}`);
  },
});

omakasePlayer.player.onEvent$.pipe(rxjs.filter((event) => event.type === omakase.PlayerEventType.PLAYER_SEEKED)).subscribe({
  next: (event) => {
    console.log(`Media seeked. Timestamp: ${event.data.currentTime}`);
  },
});

omakasePlayer.player.onEvent$.pipe(rxjs.filter((event) => event.type === omakase.PlayerEventType.PLAYER_PLAYBACK_PROGRESS)).subscribe({
  next: (event) => {
    console.log(`Media time change. Timestamp: ${event.data.currentTime}`);
  },
});
```

### Detached media player

To enable full media detaching in Omakase Player we need to instantiate a _detached_ instance of Omakase Player on same host, and tell our _local_ instance where to find it.

Local player instance configuration on `https://my-server.com/omp-player`:

```javascript
// local-omakase-player.js

// Local OmakasePlayer instance configuration on https://my-server.com/omp-player
let omakasePlayer = new omakase.OmakasePlayer({
  playerHTMLElementId: 'omakase-player',
  detachWindowUrlFn: (mainMedia) => 'https://my-server.com/player/omp-player-detached',
});
```

Detached player instance configuration on `https://my-server.com/omp-player-detached`:

```javascript
// detached-omakase-player.js

// Detached OmakasePlayer instance configuration on https://my-server.com/omp-player-detached
let omakasePlayer = new omakase.OmakasePlayerDetached({
  playerHTMLElementId: 'omakase-player',
});
```

We can now load main media, detach it to independent browser window and play it!:

```javascript
// local-omakase-player.js

omakasePlayer.loadMainMedia('https://my-server.com/myvideo.m3u8').subscribe({
  next: (mainMedia) => {
    console.log(`Main media loaded`);

    omakasePlayer.detachPlayer().subscribe(() => {
      console.log(`Main media detached`);

      omakasePlayer.player.play();
    });
  },
});
```

Due to security and usability policies, most modern browsers require a user interaction before allowing certain actions, such as video autoplay or fullscreen initiation.
It could be that one-time-only user interaction (such as clicking on play button in detached player) is needed before video playback or switching to fullscreen playback after video detaching.

### Playback engine

We can get the playback engines used for the main media. If HLS media is loaded, then hls.js instance can be fetched.

```javascript
// Get hls.js instance and hook onto hls.js events
let hlsPlaybackEngine = omakasePlayer.player.getPlaybackEngine(MainMediaType.HLS);
hlsPlaybackEngine.hls.on('hlsManifestParsed', (event, data) => {
  console.log(`HLS manifest parsed`, data);
});
```

### Utilities

```javascript
// adds safe zone 10% from all player edges
omakasePlayer.chroming.addSafeZone({
  topRightBottomLeftPercent: [10, 10, 10, 10],
});

// toggles fullscreen
omakasePlayer.player.toggleFullscreen();
```

### Live Media

Player supports live media (HLS). Live can either be `EVENT` or `CONTINUOUS`. `EVENT` live is used for live streams that don't evict segments, i.e. segments are only being appended.
`CONTINUOUS` live is used for streams that both append new segments, and delete the old ones. To ensure continuous media playback, `liveSyncPosition` is used that trails the live edge,
and constrains exposed media time — it is what `getDuration()` returns while live, and seeks are clamped to it.

We can subscribe to live state changes:

```ts
omakasePlayer.player.onEvent$.pipe(filter((event) => event.type === PlayerEventType.PLAYER_LIVE_STATE_UPDATE)).subscribe({
  next: (event) => {
    console.log(`Live sync position: ${event.data.liveState?.liveSyncPosition}`);
  },
});
```

Full `liveState` payload is available in API Reference Docs.

## Localization API

Complete list of Localization API methods is available in API Reference Docs. Exposed at the top level as `omakasePlayer.localization`, alongside `omakasePlayer.player` and `omakasePlayer.chroming`.

#### `getLocalization(key: LocalizationKey): string`

Fetches the localized string for a given key, falling back to its default value if no override was configured via `localization` (see [Player Initialization](#player-initialization)).

```javascript
const liveLabel = omakasePlayer.localization.getLocalization('live');
console.log(liveLabel); // 'LIVE', or the configured override
```

## Audio API

Complete list of Audio API methods is available in API Reference Docs.

There are two types of audio: **Main audio** and **Sidecar audio**. Main audio refers to audio source attached to main media track. Main audio tracks are embedded audio tracks loaded with main media and only single Main audio track can be active (playing) at same time. Sidecar audio tracks are loaded manually and they are independent of main media load and Main audio. Sidecar audio tracks playback is synced with main media (Main audio) playback and there can be multiple Sidecar audio tracks active (playing) at same time.

Few common usages of Audio API:

MOV audio sidecars can be loaded with `player.loadSidecarTrack(url, {trackType: TrackType.AUDIO})`.
The original MOV format is preserved; playback still requires browser support for the contained audio codec.
An HLS playlist is not an audio file and cannot be loaded with `TrackType.AUDIO`.

```javascript
// retrieves all available audio tracks
let audioTracks = omakasePlayer.player.audio.getTracks();

// detect audio tracks switching
omakasePlayer.player.audio.onEvent$.pipe(filter((event) => event.type === omakase.PlayerAudioEventType.PLAYER_AUDIO_TRACK_SWITCHED)).subscribe({
  next: (event) => {
    console.log(`Audio switched`, event);
  },
});

// sets another audio track as active
omakasePlayer.player.audio.switchTrack(audioTracks[1].id, true);
```

### Main audio router

Enables routing between audio inputs and outputs.

```javascript
// creates Main audio router configured for routing between 2 inputs and 4 outputs
omakasePlayer.player.audio
  .getHandler(PlayerAudioType.MAIN)
  .createAudioRouter(2, 4)
  .subscribe(() => {
    // connects 1st input with 2nd output
    // disconnects 2nd input and 2nd output
    omakasePlayer.player.audio.getHandler(PlayerAudioType.MAIN).router.updateConnections([
      {
        path: {input: 0, output: 1},
        connected: true,
      },
      {
        path: {input: 1, output: 1},
        connected: false,
      },
    ]);
  });
```

### Main audio peak processor

Enables audio peak processing for analyzing audio and creating audio peaks visualizations such as [VU meter](#vu-meter).

```javascript
// creates Main audio peak sample processor
omakasePlayer.player.audio.getHandler(PlayerAudioType.MAIN).createMainAudioPeakProcessor();

// listens for peak processor messages
omakasePlayer.audio.getHandler(PlayerAudioType.MAIN).onPeakProcessorEvent$.subscribe({
  next: (event) => {
    // peak processor message can be input to audio peak visualization component
    console.log(`Peak processor message`, event);
  },
});
```

### Sidecar audio

```javascript
// listens for SidecarAudioCreateEvent events
omakasePlayer.player.audio.onEvent$.pipe(rxjs.filter((event) => event.type === PlayerAudioEventType.PLAYER_AUDIO_TRACK_LOADED)).subscribe({
  next: (event) => {
    console.log(`Just created Sidecar audio track: `, event.data.playerAudioTrack);
  },
});

// listens for SidecarAudioRemoveEvent events
omakasePlayer.player.audio.onEvent$.pipe(rxjs.filter((event) => event.type === PlayerAudioEventType.PLAYER_AUDIO_TRACK_UNLOADED)).subscribe({
  next: (event) => {
    console.log(`Just removed Sidecar audio track: `, event.data.playerAudioTrack);
  },
});

// creates new Sidecar audio track
omakasePlayer.player
  .loadSidecarTrack(sidecarAudioUrl, {
    trackType: omakase.TrackType.AUDIO,
  })
  .subscribe({
    next: (sidecarAudioTrackState) => {
      console.log(`Created new Sidecar audio track with id:`, sidecarAudioTrackState.id);
    },
  });

// activates Sidecar audio tracks
omakasePlayer.player.audio.switchTrack('sidecarAudioTrackId1', true);

// deactivates Sidecar audio tracks
omakasePlayer.player.audio.switchTrack('sidecarAudioTrackId1', false);

// removes Sidecar audio tracks
omakasePlayer.player.removeSidecarTrack('sidecarAudioTrackId1');
```

### Sidecar audio router

```javascript
// listens for SidecarAudioChangeEvent events, event is triggered ie. when Sidecar audio router changes
// once the router is created you can subscribe to its event through `audioHandler.router.onEvent$`
omakasePlayer.player.audio
  .getHandler(PlayerAudioType.SIDECAR, 'sidecarAudioTrackId1')
  .onEvent$.pipe(rxjs.filter((event) => event.type === AudioHandlerEventType.AUDIO_HANDLER_CHANGE))
  .subscribe({
    next: (event) => {
      console.log(`Just changed Sidecar audio track: `, event.changedSidecarAudioState);
    },
  });

// creates Sidecar audio router configured for routing between 2 inputs and 4 outputs
omakasePlayer.player.audio.getHandler(PlayerAudioType.SIDECAR, 'sidecarAudioTrackId1').createAudioRouter(2, 4);

// connects 1st output with 2nd output
omakasePlayer.player.audio.getHandler(PlayerAudioType.SIDECAR, 'sidecarAudioTrackId1').router.updateConnections([
  {
    path: {input: 0, output: 1},
    connected: true,
  },
]);

// disconnects 2nd input and 2nd output
omakasePlayer.player.audio.getHandler(PlayerAudioType.SIDECAR, 'sidecarAudioTrackId1').router.updateConnections([
  {
    path: {input: 1, output: 1},
    connected: false,
  },
]);
```

### Sidecar audio peak processor

Enables audio peak processing for analyzing audio and creating audio peaks visualizations such as [VU meter](#vu-meter).

```javascript
// creates Sidecar audio peak sample processor
omakasePlayer.player.audio.getHandler(PlayerAudioType.SIDECAR, 'sidecarAudioTrackId1').createPeakProcessor();

// listens for peak processor messages on all Sidecar audios and filters them for single Sidecar audio track
omakasePlayer.player.audio.getHandler(PlayerAudioType.SIDECAR, 'sidecarAudioTrackId1').onPeakProcessorEvent$.subscribe({
  next: (event) => {
    // peak processor message can be input to audio peak visualization component
    console.log(`Peak processor message`, event);
  },
});
```

### Audio router visualization

Initializes the audio router visualization component. It will create the main audio router or sidecar audio routers if they are not already created.

Parameters:

- `routerVisualizationHTMLElementId`: optional, id of the HTML element inside which to render the router visualization component (defaults to `'omakase-audio-router'`)
- `size`: optional, component size (`'small'`, `'medium'` or `'large'`, defaults to `'medium'`)
- `outputNumber`: optional, number of outputs to display (defaults to the number of detected outputs from the AudioContext)
- `outputLabels`: optional, labels to display for outputs (if not provided, default labels will be shown)
- `visualizationTracks`: optional, array of router visualization tracks
  - `name`: optional, label to show for the main track
  - `maxInputNumber`: required, number of inputs for main audio router
  - `inputNumber`: optional, number of inputs to visualize (defaults to `maxInputNumber`)
  - `inputLabels`: optional, labels to display for main track inputs (if not provided, default labels will be shown)
  - `trackId`: optional, id of the sidecar audio track, if not provided the visualization track will be treated as main track

Usage example:

```html
<div id="omakase-audio-router"></div>
```

```javascript
// creates a router visualization component with one main track and one sidecar track
let routerVisualizationComponent = new RouterVisualization(
  {
    routerVisualizationHTMLElementId: 'omakase-audio-router',
    size: 'medium',
    outputNumber: 6,
    outputLabels: ['L', 'R', 'C', 'LFE', 'Ls', 'Rs'],
    visualizationTracks: [
      {
        name: '5.1 English',
        inputNumber: 6,
        maxInputNumber: 6,
        inputLabels: ['L', 'R', 'C', 'LFE', 'Ls', 'Rs'],
      },
      {
        trackId: '<sidecar_track_id>',
        name: 'Stereo',
        inputNumber: 2,
        maxInputNumber: 6,
        inputLabels: ['L', 'R', 'C', 'LFE', 'Ls', 'Rs'],
      },
    ],
  },
  omakasePlayer
);
```

For detailed styling variables please check [Audio Router](https://api.player.byomakase.org/documents/OmakasePlayer.STYLING.html#audio-router) in Styling documentation.

### Audio Effects

Omakase Player supports applying audio effects on main, sidecar, and output audio handlers. Effects are added using `AudioEffectDef` interface that Omakase Player instantiates into corresponding specific `AudioEffect` and includes it into the handlers audio chain. To use effects not provided by Omakase Player, you need to register the factory functions that will convert effect definitions to concrete effect objects. User never creates specific effects, only their definitions.

Omakase Player supports three predefined effect chain slots: `source`, `router` and `destination` in different audio chain locations. These slots are independent and can host audio effect chains simultaneously. Each audio handler has independent slots.

The audio chains samples for main media and one audio sidecar are shown in the image below:

![audio chain](https://api.player.byomakase.org/static/audio-effect-chain.png)

Adding effects to `router` slot can be further granulated with routing path that can select specific connections and apply effects on specified connections only.

Usage example:

```js
let mainEchoEffectDef = AudioEffectGraphDef.create(
  GainEffect.createDef('gain1', 1).outputTo({effectId: 'delay1'}),
  DelayEffect.createDef('delay1', 0.2).outputTo('feedbackGain', 'gain2'),
  GainEffect.createDef('feedbackGain', 0.5).outputTo('delay1'),
  GainEffect.createDef('gain2', 1)
);

let sidecarBalanceEffectDef = AudioEffectGraphDef.create(GainEffect.createDef('gain', 1));

// create echo effect graph on the main audio track at source slot
omakasePlayer.player.audio.getHandler(PlayerAudioType.MAIN).effects.setEffectGraph(mainEchoEffectDef, {slot: 'source'});

// create sidecar audio router
omakasePlayer.player.audio
  .getHandler(PlayerAudioType.SIDECAR, 'sidecarAudioTrackId1')
  .createAudioRouter()
  .subscribe(() => {
    // creates echo effect graph on the sidecar audio track at router slot on all routing paths
    omakasePlayer.player.audio.getHandler(PlayerAudioType.SIDECAR, 'sidecarAudioTrackId1').effects.setEffectGraph(sidecarBalanceEffectDef, {slot: 'router'});
  });
```

Omakase Player supports changing effects parameters once the effects are created.

Usage example:

```js
// changes gain parameter of gain effect with id "gain" on routing paths terminating on output 0 inside the router slot
omakasePlayer.player.audio
  .getHandler(PlayerAudioType.SIDECAR, 'sidecarAudioTrackId1')
  .effects.setEffectsParams(new AudioEffectGainParam(0.8), {slot: 'router', routingPath: {output: 0}}, {id: 'gain'});

// changes gain parameter of gain effect with id "gain" on routing paths terminating on output 1 inside the router slot
omakasePlayer.player.audio
  .getHandler(PlayerAudioType.SIDECAR, 'sidecarAudioTrackId1')
  .effects.setEffectsParams(new AudioEffectGainParam(1.2), {slot: 'router', routingPath: {output: 1}}, {id: 'gain'});
```

#### Included audio effects

While Omakase Player supports custom audio effects as long as they conform to `AudioEffect` interface, Omakase Player provides some audio effects to make more common use cases (for example audio balancing) easier.

##### GainEffect

GainEffect implements gain effect. Supported parameters are the same as web audio's [GainNode](https://webaudio.github.io/web-audio-api/#GainNode).

To make usage easier Omakase Player provides `AudioEffectGainParam` wrapper around the gain parameter.

To create effect definition use `GainEffect.createDef` static method.

Code sample:

```js
let graphDef = AudioEffectGraphDef.create(GainEffect.createDef('gain', 0.5));

omakasePlayer.player.audio.getHandler(PlayerAudioType.MAIN).effects.setEffectGraph(graphDef, {slot: 'source'});
```

##### DelayEffect

DelayEffect implements delay effect. Supported parameters are the same as web audio's [DelayNode](https://webaudio.github.io/web-audio-api/#DelayNode).

To make usage easier Omakase Player provides `AudioEffectDelayTimeParam` wrapper around the delayTime parameter.

To create effect definition use `DelayEffect.createDef` static method.

Code sample:

```js
let graphDef = AudioEffectsGraphDef.create(DelayEffect.createDef('delay', 0.2));

omakasePlayer.player.audio.getHandler(PlayerAudioType.MAIN).effects.setEffectGraph(graphDef, {slot: 'destination'});
```

## Styling

For detailed styling structure and variables please check [Styling](https://api.player.byomakase.org/documents/OmakasePlayer.STYLING.html#styling).

## Text API

Complete list of Text API methods is available in API Reference Docs.
Omakase Player automatically identifies all available text tracks from main media and makes them available through Text API.

```javascript
omakasePlayer.player.onEvent$.pipe(rxjs.filter((event) => event.type === PlayerEventType.PLAYER_MAIN_MEDIA_LOADED)).subscribe({
  next: (event) => {
    // retrieves all subtitles VTT tracks
    let textTracks = omakasePlayer.player.text.getTracks();

    // shows first available VTT track
    omakasePlayer.player.text.switchTrack(textTracks[0].id, true);
  },
});
```

Subtitles can be imported from external VTT file:

```javascript
// import subtitles from VTT file
omakasePlayer.player
  .loadSidecarTrack('https://example.com/myTextTrack.vtt', {
    trackType: TrackType.TEXT_TRACK,
    args: {
      id: '0',
      label: 'English (US)',
      default: true,
      srcLang: 'EN',
    },
  })
  .subscribe({
    next: (textTrackState) => {
      console.log(`Subtitles successfully created`);
    },
  });
```

Sidecar text tracks also support SRT, SSA, ASS, TTML/DFXP, and SCC. SCC files are decoded to captions by the player; TTML/DFXP is rendered with the IMSC text handler. Set `fileFormatType` in the sidecar load options when the format cannot be inferred from the URL (for example, an XML-named DFXP file):

```javascript
import {FileFormatType, TrackType} from '@byomakase/omakase-player';

omakasePlayer.player.loadSidecarTrack('https://example.com/captions.xml', {
  trackType: TrackType.TEXT_TRACK,
  fileFormatType: FileFormatType.TTML,
  args: {id: 'captions', label: 'English', srclang: 'en'},
});
```

## Tracks

### Marker track

A **marker track** is a type of **timed items track** — a track that holds a collection of time-anchored data points called _timed items_. Each timed item has a temporal position (a moment or a time span) and an arbitrary data payload. The marker track specialises this concept for timeline annotations: each timed item is a **marker** that can represent either a single point in time (a moment marker) or a duration (a spanning marker).

Marker data is typically loaded from a [WebVTT](https://www.w3.org/TR/webvtt1/) file, where each cue becomes one marker. When a cue covers an instant it becomes a `MOMENT_MARKER`; when it covers a range it becomes a `SPANNING_MARKER`.

#### Constructor arguments

`MarkerTrack` accepts an optional configuration object with the following fields:

| Argument           | Type             | Description                                                                                                                 |
| ------------------ | ---------------- | --------------------------------------------------------------------------------------------------------------------------- |
| `id`               | `string`         | Optional pre-assigned UUID. A new UUID is generated automatically when omitted.                                             |
| `source`           | `UrlSource`      | URL source that points to a VTT file containing marker data. Takes precedence over `url`.                                   |
| `label`            | `string`         | Human-readable label for this track.                                                                                        |
| `timedItemsLocked` | `boolean`        | When `true`, the track is locked — markers cannot be added, deleted, or updated after the track loads. Defaults to `false`. |
| `timedItemHooks`   | `TimedItemHooks` | Lifecycle hooks called during marker creation. See [Timed item hooks](#timed-item-hooks) below.                             |

**Loading markers from a VTT file via `source`:**

```ts
import {MarkerTrack, UrlSource, TrackType} from '@byomakase/omakase-player';

const track = omakasePlayer.track.add(
  new MarkerTrack({
    source: UrlSource.of('https://example.com/data/markers.vtt'),
  })
);

omakasePlayer.track.load(TrackSource.fromTrack(track), {
  trackType: TrackType.MARKER_TRACK,
});
```

#### Locked and unlocked timed items

Every timed items track has a **locked** flag (`timedItemsLocked`) that controls whether its collection of timed items is mutable after the initial load.

- **Unlocked** (default) — markers can be added, removed, and updated freely at any time via `addTimedItems`, `deleteTimedItems`, and `updateTimedItem`. This is useful when you want to programmatically build or edit the marker collection at runtime.
- **Locked** — once the track has finished fetching its data any call to `addTimedItems`, `deleteTimedItems`, or `updateTimedItem` throws an error. Use this when the marker data comes from a canonical source and must not be altered.

```ts
// Locked — markers cannot be mutated after load
const track = omakasePlayer.track.add(
  new MarkerTrack({
    source: UrlSource.of('https://example.com/data/markers.vtt'),
    timedItemsLocked: true,
  })
);

// Unlocked — add markers programmatically
const editableTrack = omakasePlayer.track.add(new MarkerTrack());

editableTrack.addTimedItems(
  new DefaultMarker({
    temporal: {type: TimedItemTemporalType.MOMENT, time: '42'},
    label: 'Scene cut',
  })
);
```

The locked state can also be toggled at runtime:

```ts
track.areTimedItemsLocked = false; // unlock
track.areTimedItemsLocked = true; // lock again
```

#### Timed item hooks

`timedItemHooks` lets you run callbacks at specific points in a marker's lifecycle. Both hooks receive the timed item instance as their argument.

| Hook           | When it fires                                                                                                                                                          |
| -------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `beforeCreate` | Immediately before the marker is inserted into the track's internal collection. Use this to apply styles or perform setup that must happen before the item is visible. |
| `afterCreate`  | Immediately after the marker has been inserted and the track has emitted its update events. Use this for post-creation side effects.                                   |

```ts
const track = omakasePlayer.track.add(
  new MarkerTrack({
    source: UrlSource.of('https://example.com/data/markers.vtt'),
    timedItemsLocked: true,
    timedItemHooks: {
      beforeCreate: (timedItem) => {
        // Assign a random colour to each marker before it is rendered
        omakasePlayer.ui.updateStyleRule({
          id: timedItem.id,
          style: {color: ColorUtil.randomHexColor()},
        });
      },
      afterCreate: (timedItem) => {
        console.log('Marker created:', timedItem.id);
      },
    },
  })
);
```

#### Timed items track interface

The following methods are available on any `TimedItemsTrack`, including `MarkerTrack`.

---

**`timedItems`** — Returns the full array of timed items in insertion order.

```ts
const all = track.timedItems;
```

---

**`timedItemsSorted`** — Returns the timed items sorted ascending by their start time. Items without a start time (e.g. `SPAN_END` temporals) appear first.

```ts
const sorted = track.timedItemsSorted;
```

---

**`areTimedItemsLocked`** — `true` when the track is locked and its items cannot be mutated. Can be read and set.

```ts
if (!track.areTimedItemsLocked) {
  track.addTimedItems(newMarker);
}
```

---

**`getTimedItem(id)`** — Returns the timed item with the given UUID, or `undefined` if not found.

```ts
const marker = track.getTimedItem('some-uuid');
```

---

**`addTimedItems(timedItems)`** — Adds one or more timed items to the track. Throws if the track is locked. Fires `beforeCreate` and `afterCreate` hooks for each item.

```ts
track.addTimedItems(marker);
track.addTimedItems([markerA, markerB]);
```

---

**`deleteTimedItems(id)`** — Removes one or more timed items by their UUID. Throws if the track is locked.

```ts
track.deleteTimedItems('some-uuid');
track.deleteTimedItems(['uuid-1', 'uuid-2']);
```

---

**`updateTimedItem(id, attrs)`** — Updates mutable attributes (`temporal`, `data`, `label` for markers) of the item with the given UUID. Throws if the track is locked.

```ts
track.updateTimedItem('some-uuid', {
  label: 'Updated label',
  temporal: {type: TimedItemTemporalType.MOMENT, time: '60'},
});
```

---

**`findTimedItemsAtTime(time)`** — Returns all timed items whose temporal range covers the given time (in seconds).

- `MOMENT` — matches when `time === temporal.time`
- `SPAN` — matches when `temporal.start <= time <= temporal.end`
- `SPAN_START` — matches when `temporal.start <= time`
- `SPAN_END` — matches when `temporal.end >= time`

```ts
const active = track.findTimedItemsAtTime(30);
```

---

**`findFirstTimedItemAtTime(time)`** — Like `findTimedItemsAtTime` but returns only the first match (by sorted order), or `undefined` if none.

```ts
const first = track.findFirstTimedItemAtTime(30);
```

---

**`findTimedItemsInRange(start, end)`** — Returns all timed items that fall fully within the `[start, end]` range. Items that merely overlap the range boundaries are excluded (except `SPAN_START` items, which are included when their start falls in range).

```ts
const inRange = track.findTimedItemsInRange(10, 60);
```

---

**`findNearestTimedItem(time)`** — Returns the timed item whose start time is closest to `time`. When two items are equidistant, the one before `time` wins. Returns `undefined` if the track is empty.

```ts
const nearest = track.findNearestTimedItem(45);
```

## Timeline

The **timeline** is an interactive canvas-based interface. It renders a playhead, a scrubber, optional thumbnails, and any number of **timeline lanes** that visualise track data.

For detailed styling variables please check [Timeline](https://api.player.byomakase.org/documents/OmakasePlayer.STYLING.html#timeline) in Styling documentation.

### Creating a timeline

Call `createTimeline` on the player instance. It returns an `Observable<TimelineApi>` that emits once the timeline canvas has been mounted.

```ts
import {OmakasePlayer} from '@byomakase/omakase-player';

omakasePlayer
  .createTimeline({
    style: {
      minWidth: 700,
      backgroundFill: '#E4E5E5',
      headerBackgroundFill: '#EDEFEE',
      footerBackgroundFill: '#EDEFEE',

      playheadVisible: true,
      playheadFill: '#000000',
      playheadLineWidth: 2,

      playheadPlayProgressFill: '#008cbc',
      playheadPlayProgressOpacity: 0.5,

      playheadBufferedFill: '#a2a2a2',
      playheadBufferedOpacity: 1,

      scrubberSouthLineOpacity: 0.2,
    },
  })
  .subscribe((timeline) => {
    // timeline is a TimelineApi instance
  });
```

Created timelines are accessible via `omakasePlayer.timelines` and `omakasePlayer.getTimeline(id)`. The `omakasePlayer.timeline` getter still returns the first created timeline but is deprecated.

### Multiple timelines

Several timelines can exist at the same time, all driven by the same player. Each timeline is appended to the end of the DOM element given by `htmlElementId`, so timelines can share an element (stacked in creation order) or live in separate elements.

```ts
omakasePlayer.createTimeline({htmlElementId: 'timeline-overview'}).subscribe((overview) => {
  // ...
});

omakasePlayer.createTimeline({htmlElementId: 'timeline-detail'}).subscribe((detail) => {
  omakasePlayer.timelines; // [overview, detail]
  omakasePlayer.getTimeline(detail.id); // detail
});
```

Destroying a timeline with `timeline.destroy()` removes its DOM from the host element and removes it from `omakasePlayer.timelines`; other timelines in the same element are not affected. A timeline lane instance can belong to only one timeline, so create a separate lane for each timeline.

### Configuration

`createTimeline` accepts a `TimelineConfig` object alongside `style` (passed as top-level fields, not nested under `style`):

| Field                               | Type      | Default              | Description                                                                                                                  |
| ----------------------------------- | --------- | -------------------- | ---------------------------------------------------------------------------------------------------------------------------- |
| `htmlElementId`                     | `string`  | `'omakase-timeline'` | Id of the DOM element the timeline is appended to.                                                                           |
| `scrubberSnapArea`                  | `number`  | `5`                  | Pixel distance from the playhead within which the hover scrubber snaps to it.                                                |
| `playheadDragScrollMaxSpeedAfterPx` | `number`  | `100`                | Pixel distance past the viewport edge, while dragging the playhead, beyond which auto-scroll speed is capped at its maximum. |
| `zoomWheelEnabled`                  | `boolean` | `true`               | Enables zooming the timeline with the mouse wheel.                                                                           |
| `zoomScale`                         | `number`  | `1.7`                | Zoom multiplier applied per `zoomInEased()`/`zoomOutEased()` call.                                                           |
| `zoomScaleWheel`                    | `number`  | `1.05`               | Zoom multiplier applied per mouse-wheel zoom step.                                                                           |
| `zoomBaseline`                      | `number`  | `100`                | Minimum zoom percent (fully zoomed out).                                                                                     |
| `zoomMax`                           | `number`  | `2000`               | Maximum zoom percent (fully zoomed in).                                                                                      |
| `layoutEasingDuration`              | `number`  | `500`                | Default easing duration in milliseconds for lane minimize/maximize animations.                                               |
| `zoomEasingDuration`                | `number`  | `800`                | Default easing duration in milliseconds for `zoomToEased`/`zoomInEased`/`zoomOutEased`/`zoomToMaxEased`.                     |
| `scrollEasingDuration`              | `number`  | `200`                | Default easing duration in milliseconds for `scrollToEased`/`scrollToPlayheadEased`.                                         |
| `scrubberClickSeek`                 | `boolean` | `true`               | Clicking the timecode axis seeks playback to that position.                                                                  |
| `timecodeClickEdit`                 | `boolean` | `true`               | Double-clicking the CTI timecode display toggles it into an editable state (see `toggleTimecodeEdit()`).                     |
| `descriptionPaneVisible`            | `boolean` | `true`               | Initial visibility of the description (left) pane. Toggle later with `setDescriptionPaneVisible()`.                          |

```ts
omakasePlayer.createTimeline({
  zoomMax: 4000,
  scrubberClickSeek: false,
  style: {
    /* ... */
  },
});
```

### Adding and removing lanes

A timeline has three slots — `HEADER`, `MAIN`, and `FOOTER` — stacked vertically, with `MAIN` the primary, scrollable content area. Lanes are added to the `MAIN` slot by default. The `HEADER` slot always contains the built-in [scrubber lane](#scrubber-lane) in addition to any lanes you add. See [Slots](#slots) for the slot-level API and for adding lanes to `HEADER`/`FOOTER`.

```ts
import {TimelineSlotType} from '@byomakase/omakase-player';

// Add a single lane (defaults to the MAIN slot, appended at the end)
timeline.addTimelineLane(lane);

// Add a lane at a specific index within its slot
timeline.addTimelineLane(lane, {index: 0});

// Add a lane to a specific slot
timeline.addTimelineLane(lane, {slot: TimelineSlotType.HEADER});

// Add a lane to a specific slot at a specific index
timeline.addTimelineLane(lane, {slot: TimelineSlotType.FOOTER, index: 0});

// Add multiple lanes at once — same {index, slot} options as addTimelineLane;
// index is the starting index and each subsequent lane is inserted right after the previous one
timeline.addTimelineLanes([laneA, laneB, laneC]);
timeline.addTimelineLanes([laneA, laneB], {slot: TimelineSlotType.HEADER});

// Remove by id
timeline.removeTimelineLane(lane.id);
timeline.removeTimelineLanes([laneA.id, laneB.id]);
timeline.removeAllTimelineLanes();

// Retrieve lanes
const mainLanes = timeline.getTimelineLanes(); // MAIN slot only (backward-compatible shortcut)
const headerLanes = timeline.getTimelineLanes(TimelineSlotType.HEADER);
const single = timeline.getTimelineLane<MarkerTrackLane>('some-id');
const scrubber = timeline.scrubberLane;
```

### Slots

Every timeline has three slots, each implementing `TimelineSlotApi`:

| Slot     | Behaviour                                                                                                                           |
| -------- | ----------------------------------------------------------------------------------------------------------------------------------- |
| `HEADER` | Adaptive height (grows/shrinks with its lanes), stacked above `MAIN`. Always contains the built-in [scrubber lane](#scrubber-lane). |
| `MAIN`   | Bounded/scrollable height — the primary content area. The only slot with real vertical scroll.                                      |
| `FOOTER` | Adaptive height, stacked below `MAIN`.                                                                                              |

```ts
import {TimelineSlotType, TimelineSlotEventType} from '@byomakase/omakase-player';

const mainSlot = timeline.getSlot(TimelineSlotType.MAIN);

mainSlot.addTimelineLane(lane); // appends to this slot; accepts an optional index
mainSlot.removeTimelineLane(lane.id);
mainSlot.getTimelineLanes();
mainSlot.getEffectiveHeight(); // current rendered height in pixels
mainSlot.getContentHeight(); // total height of all lanes in this slot, in pixels
mainSlot.setVerticalScrollbarVisible(true); // MAIN only; no-op on HEADER/FOOTER

// Vertical scroll — only meaningful for MAIN; HEADER/FOOTER expose a no-op adapter
mainSlot.scroll.scrollTo(50); // percent, 0-100
mainSlot.scroll.scrollBy(10, {easing: true});
mainSlot.scroll.onScroll$.subscribe(({scrollPercent, deltaPercent}) => {
  /* ... */
});

// Slot-level events — resize (any slot) and scroll (MAIN only)
mainSlot.onEvent$.subscribe((event) => {
  if (event.type === TimelineSlotEventType.TIMELINE_SLOT_RESIZE) {
    console.log('slot height may have changed');
  }
  if (event.type === TimelineSlotEventType.TIMELINE_SLOT_SCROLL) {
    console.log(event.data.scrollPercent, event.data.deltaPercent);
  }
});
```

### Common lane configuration

Every lane type extends `TimelineLaneConfig` and `TimelineLaneStyle`.

**`TimelineLaneConfig`**

| Field                  | Type      | Description                                                                                                  |
| ---------------------- | --------- | ------------------------------------------------------------------------------------------------------------ |
| `description`          | `string`  | Text shown in the left description pane. When omitted, the associated track's `label` is used automatically. |
| `minimized`            | `boolean` | Start the lane in its collapsed (zero-height) state. Defaults to `false`.                                    |
| `layoutEasingDuration` | `number`  | Easing duration in milliseconds for minimize/maximize animations.                                            |

Every lane exposes `minimize()`, `maximize()`, and `toggleMinimizeMaximize()`. All three accept an optional `TimelineLaneMinimizeMaximizeArgs` object:

| Field      | Type               | Description                                                                                       |
| ---------- | ------------------ | ------------------------------------------------------------------------------------------------- |
| `easing`   | `boolean`          | Animate the height change. Defaults to `false`.                                                   |
| `duration` | `number`           | Animation duration in milliseconds. Defaults to the timeline easing duration.                     |
| `complete` | `Observable<void>` | **Set by the method.** Completes when the operation finishes. Subscribe after calling the method. |

```ts
const args: TimelineLaneMinimizeMaximizeArgs = {easing: true};
lane.minimize(args);
args.complete!.subscribe({complete: () => console.log('minimize done')});
```

### Lane types

#### Scrubber lane

The **scrubber lane** is created automatically in the `HEADER` slot when a timeline is instantiated, and cannot be removed or moved to another slot. It renders timecode ticks along the time axis and drives the hover scrubber. Retrieve the instance with `timeline.scrubberLane`.

---

#### Marker track lane

A **`MarkerTrackLane`** is a multi-track lane — it can hold one or more `MarkerTrack` instances simultaneously. Each marker appears as a symbol (moment markers) or a shaded region (spanning markers). After adding the lane to the timeline, call `addTrack` to bind a track. Each track can carry its own per-track style.

```ts
import {MarkerTrackLane} from '@byomakase/omakase-player';

const markerLane = new MarkerTrackLane({
  description: 'Scene cuts',
});

timeline.addTimelineLane(markerLane);
markerLane.addTrack(markerTrack);
```

**Adding multiple tracks to one lane:**

```ts
// Two tracks rendered in the same lane with different colors
markerLane.addTrack(dialogTrack, {
  style: {markerColor: '#2196f3'},
});

markerLane.addTrack(blackSegmentsTrack, {
  style: {
    markerColor: '#4caf50',
    markerRenderType: 'spanning-over-all-lanes',
  },
});
```

**Per-track config fields** (passed as second argument to `addTrack`)

| Field                    | Type     | Description                                                                      |
| ------------------------ | -------- | -------------------------------------------------------------------------------- |
| `trackOrderIndex`        | `number` | Zero-based index at which to insert the track. Appended at the end when omitted. |
| `style.markerColor`      | `string` | Colour applied to all markers from this track.                                   |
| `style.markerRenderType` | `string` | Render mode: `'default'`, `'spanning'`, or `'spanning-over-all-lanes'`.          |

**Events** — emitted via `markerLane.onEvent$`

| Event type                                    | Payload                 | Description                   |
| --------------------------------------------- | ----------------------- | ----------------------------- |
| `TIMELINE_MARKER_TRACK_LANE_ITEM_CLICK`       | `{ item: MarkerState }` | A marker was clicked.         |
| `TIMELINE_MARKER_TRACK_LANE_ITEM_MOUSE_ENTER` | `{ item: MarkerState }` | The pointer entered a marker. |
| `TIMELINE_MARKER_TRACK_LANE_ITEM_MOUSE_LEAVE` | `{ item: MarkerState }` | The pointer left a marker.    |

```ts
import {MarkerTrackLaneEventType} from '@byomakase/omakase-player';

markerLane.onEvent$.subscribe((event) => {
  if (event.type === MarkerTrackLaneEventType.TIMELINE_MARKER_TRACK_LANE_ITEM_CLICK) {
    console.log('Clicked marker:', event.data.item.id);
  }
});
```

**Marker view style** — individual marker appearance can be customised at runtime:

```ts
// Apply a style to specific markers by their IDs
markerLane.setMarkerViewStyle({markerColor: '#ff0000', markerRenderType: 'default'}, [markerId1, markerId2]);

// Apply a style to all markers in the lane
markerLane.setMarkerViewStyle({markerColor: '#00ff00'});
```

---

#### Thumbnail track lane

A **`ThumbnailTrackLane`** renders a `ThumbnailTrack` as a filmstrip of images across the timeline. After adding the lane, call `setTrack` to bind it to a loaded `ThumbnailTrack`. To also enable the timeline-wide thumbnail hover preview, call `timeline.setThumbnailTrack(track)`.

```ts
import {ThumbnailTrackLane} from '@byomakase/omakase-player';

const thumbnailLane = new ThumbnailTrackLane();

timeline.setThumbnailTrack(thumbnailTrack); // enables hover preview on Scrubber lane
thumbnailLane.setTrack(thumbnailTrack);
timeline.addTimelineLane(thumbnailLane);
```

**Events** — emitted via `thumbnailLane.onEvent$`

| Event type                                            | Payload                                         | Description                      |
| ----------------------------------------------------- | ----------------------------------------------- | -------------------------------- |
| `TIMELINE_THUMBNAIL_TRACK_LANE_THUMBNAIL_CLICK`       | `{ thumbnailTrackImg: ThumbnailTrackImgState }` | A thumbnail was clicked.         |
| `TIMELINE_THUMBNAIL_TRACK_LANE_THUMBNAIL_MOUSE_ENTER` | `{ thumbnailTrackImg: ThumbnailTrackImgState }` | The pointer entered a thumbnail. |
| `TIMELINE_THUMBNAIL_TRACK_LANE_THUMBNAIL_MOUSE_LEAVE` | `{ thumbnailTrackImg: ThumbnailTrackImgState }` | The pointer left a thumbnail.    |

```ts
import {ThumbnailTrackLaneEventType, TimedItemTemporalUtil} from '@byomakase/omakase-player';

thumbnailLane.onEvent$.subscribe((event) => {
  if (event.type === ThumbnailTrackLaneEventType.TIMELINE_THUMBNAIL_TRACK_LANE_THUMBNAIL_CLICK) {
    const startTime = TimedItemTemporalUtil.extractStartTime(event.data.thumbnailTrackImg.thumbnail.temporal);
    omakasePlayer.player.seekTo(Number(startTime));
  }
});
```

---

#### Text track lane

A **`TextTrackLane`** renders a `TextTrack` (subtitles or captions) as coloured blocks whose width represents each cue's duration. Adjacent cues separated by less than half a pixel are merged into a single block. After adding the lane, call `setTrack` to bind it to a loaded `TextTrack`.

```ts
import {TextTrackLane} from '@byomakase/omakase-player';

const textLane = new TextTrackLane({
  description: 'Subtitles',
});

textLane.setTrack(textTrack);
timeline.addTimelineLane(textLane);
```

**Events** — emitted via `textLane.onEvent$`

| Event type                                  | Payload               | Description                                                                  |
| ------------------------------------------- | --------------------- | ---------------------------------------------------------------------------- |
| `TIMELINE_TEXT_TRACK_LANE_ITEM_CLICK`       | `{ cues: TextCue[] }` | A cue block was clicked. The array contains all cues merged into that block. |
| `TIMELINE_TEXT_TRACK_LANE_ITEM_MOUSE_ENTER` | `{ cues: TextCue[] }` | The pointer entered a cue block.                                             |
| `TIMELINE_TEXT_TRACK_LANE_ITEM_MOUSE_LEAVE` | `{ cues: TextCue[] }` | The pointer left a cue block.                                                |

```ts
import {TextTrackLaneEventType} from '@byomakase/omakase-player';

textLane.onEvent$.subscribe((event) => {
  if (event.type === TextTrackLaneEventType.TIMELINE_TEXT_TRACK_LANE_ITEM_CLICK) {
    console.log(
      'Cue text:',
      event.data.cues.map((c) => c.text)
    );
  }
});
```

---

#### Label lane

A **`LabelLane`** renders a static text string in the timeline. It has no associated track and is useful for grouping or annotating other lanes visually. The `text` field is required.

```ts
import {LabelLane} from '@byomakase/omakase-player';

const labelLane = new LabelLane({
  text: 'Audio tracks',
  style: {
    height: 24,
    textFill: '#444444',
    textFontSize: 12,
  },
});

timeline.addTimelineLane(labelLane);
```

---

#### Bar chart lane

A **`BarChartLane`** is a multi-track lane that renders time-series observation data as vertical bars. Each track is added via `addTrack` with its own scale, interpolation settings, and per-measurement visual style.

```ts
import {BarChartLane} from '@byomakase/omakase-player';

const lane = new BarChartLane({
  description: 'Loudness',
  style: {height: 80},
});

timeline.addTimelineLane(lane);

lane.addTrack(observationTrack, {
  scale: {min: -1, max: 1},
  scaleBaseline: 0,
  interpolationStrategy: 'avg',
  interpolationWidth: 5,
  style: {
    measurements: [
      {
        measurement: 'max',
        fill: '#2196f3',
        cornerRadius: [2, 2, 0, 0],
        paddingX: 1,
      },
      {
        measurement: 'min',
        fill: '#2196f3',
        cornerRadius: [0, 0, 2, 2],
        paddingX: 1,
      },
    ],
  },
});
```

**Per-track config fields** (passed as second argument to `addTrack`)

| Field                   | Type                                           | Description                                                           |
| ----------------------- | ---------------------------------------------- | --------------------------------------------------------------------- |
| `scale`                 | `{ min, max }`                                 | Value domain. Auto-derived from data when omitted.                    |
| `scaleBaseline`         | `number`                                       | Value that maps to the bar baseline (zero-crossing). Defaults to `0`. |
| `interpolationStrategy` | `'avg' \| 'max' \| 'min'`                      | Aggregation strategy when multiple samples fall in one bucket.        |
| `interpolationWidth`    | `number`                                       | Width in pixels of one interpolation bucket.                          |
| `style.measurements`    | `Partial<BarChartLaneTrackMeasurementStyle>[]` | Per-measurement visual overrides.                                     |

**Per-measurement style fields** (`BarChartLaneTrackMeasurementStyle`)

| Field                          | Type                                         | Description                                                                                   |
| ------------------------------ | -------------------------------------------- | --------------------------------------------------------------------------------------------- |
| `measurement`                  | `string`                                     | Measurement to match (e.g. `'max'`, `'min'`, `'value'`).                                      |
| `barType`                      | `'default' \| 'og'`                          | `'default'` draws rectangles; `'og'` draws a column of stacked circles.                       |
| `fill`                         | `string`                                     | Solid fill color.                                                                             |
| `fillLinearGradientColorStops` | `(number \| string)[]`                       | Gradient color stops (Konva format). Used when `fill` is not set.                             |
| `opacity`                      | `number`                                     | Bar opacity (0–1).                                                                            |
| `cornerRadius`                 | `number \| [number, number, number, number]` | Corner radius for `'default'` bars.                                                           |
| `paddingX`                     | `number \| [number, number]`                 | Horizontal padding inside the bar's width. Single value = symmetric; tuple = `[left, right]`. |

**OG bar type example:**

```ts
lane.addTrack(observationTrack, {
  scale: {min: -1, max: 1},
  scaleBaseline: 0,
  style: {
    measurements: [
      {
        measurement: 'value',
        barType: 'og',
        fill: '#40ff00',
        paddingX: 1,
      },
    ],
  },
});
```

---

#### Line chart lane

A **`LineChartLane`** is a multi-track lane that renders time-series observation data as a polyline connecting interpolated data points. Each track is added via `addTrack` with its own scale, interpolation settings, and per-measurement visual style. Area fills above and below the line are optional.

```ts
import {LineChartLane} from '@byomakase/omakase-player';

const lane = new LineChartLane({
  description: 'Waveform',
  style: {height: 100},
});

timeline.addTimelineLane(lane);

lane.addTrack(observationTrack, {
  scale: {min: -1, max: 1},
  scaleBaseline: 0,
  interpolationStrategy: 'avg',
  interpolationWidth: 5,
  style: {
    measurements: [
      {
        measurement: 'value',
        lineStroke: '#4caf50',
        lineStrokeWidth: 2,
        pointFill: '#4caf50',
        pointRadius: 3,
      },
    ],
  },
});
```

**Per-track config fields** — same as `BarChartLane` (`scale`, `scaleBaseline`, `interpolationStrategy`, `interpolationWidth`, `style.measurements`).

**Per-measurement style fields** (`LineChartLaneTrackMeasurementStyle`)

| Field                               | Type                   | Description                                                    |
| ----------------------------------- | ---------------------- | -------------------------------------------------------------- |
| `measurement`                       | `string`               | Measurement to match.                                          |
| `lineStroke`                        | `string`               | Polyline color.                                                |
| `lineStrokeWidth`                   | `number`               | Polyline width in pixels.                                      |
| `lineDash`                          | `number[]`             | Dash pattern (Konva format).                                   |
| `lineOpacity`                       | `number`               | Polyline opacity (0–1).                                        |
| `pointRadius`                       | `number`               | Data-point circle radius in pixels.                            |
| `pointFill`                         | `string`               | Data-point fill color.                                         |
| `pointOpacity`                      | `number`               | Data-point opacity (0–1).                                      |
| `fillBelow`                         | `string`               | Solid fill for the area below the line.                        |
| `fillBelowLinearGradientColorStops` | `(number \| string)[]` | Gradient color stops for the area below the line (top→bottom). |
| `fillAbove`                         | `string`               | Solid fill for the area above the line.                        |
| `fillAboveLinearGradientColorStops` | `(number \| string)[]` | Gradient color stops for the area above the line (bottom→top). |

**Area fill example:**

```ts
lane.addTrack(observationTrack, {
  scale: {min: -1, max: 1},
  scaleBaseline: 0,
  style: {
    measurements: [
      {
        measurement: 'value',
        lineStroke: '#085b9c',
        fillBelowLinearGradientColorStops: [0, '#ffffff', 0.5, '#00a696', 1, '#005ba6'],
        fillAboveLinearGradientColorStops: [0, '#005ba6', 1, '#000000'],
      },
    ],
  },
});
```

**Multiple tracks in one lane:**

```ts
lane.addTrack(leftChannelTrack, {
  style: {measurements: [{measurement: 'value', lineStroke: '#2196f3', lineStrokeWidth: 1.5}]},
});

lane.addTrack(rightChannelTrack, {
  style: {measurements: [{measurement: 'value', lineStroke: '#f67944', lineStrokeWidth: 1.5}]},
});
```

#### Scrollbar lane

A **`ScrollbarLane`** renders a horizontal scrollbar that lets users pan and zoom the timeline. It has no associated track. The scrollbar handle reflects the current scroll position and its width reflects the current zoom level — dragging it scrolls the timeline, and pinching or scrolling on it zooms in/out.

```ts
import {ScrollbarLane} from '@byomakase/omakase-player';

const scrollbarLane = new ScrollbarLane({
  style: {
    height: 40,
    scrollbarHeight: 14,
    scrollbarWidth: '100%',
    scrollbarBackgroundFill: '#000000',
    scrollbarBackgroundFillOpacity: 0.3,
    scrollbarHandleBarFill: '#01a6f0',
    scrollbarHandleBarOpacity: 1,
    scrollbarHandleOpacity: 1,
    scrollbarJustify: 'center',
  },
});

timeline.addTimelineLane(scrollbarLane);
```

**`ScrollbarLaneStyle`**

| Field                            | Type                           | Description                                                                                             |
| -------------------------------- | ------------------------------ | ------------------------------------------------------------------------------------------------------- |
| `scrollbarWidth`                 | `number \| string`             | Width of the scrollbar track. Accepts a pixel value or `'100%'` to fill the lane. Defaults to `'100%'`. |
| `scrollbarHeight`                | `number \| undefined`          | Height of the scrollbar handle bar in pixels. When omitted, fills the full lane height.                 |
| `scrollbarBackgroundFill`        | `Color`                        | Fill color of the scrollbar track background.                                                           |
| `scrollbarBackgroundFillOpacity` | `number`                       | Opacity of the track background (0–1).                                                                  |
| `scrollbarHandleBarFill`         | `Color`                        | Fill color of the draggable handle bar.                                                                 |
| `scrollbarHandleBarOpacity`      | `number`                       | Opacity of the handle bar (0–1).                                                                        |
| `scrollbarHandleOpacity`         | `number`                       | Opacity of the entire scrollbar handle (0–1).                                                           |
| `scrollbarJustify`               | `'start' \| 'center' \| 'end'` | Vertical alignment of the scrollbar within the lane. Defaults to `'center'`.                            |

---

### Events

All timeline-wide events are emitted via the `onEvent$` observable. The following event types are available:

- `TimelineEventType.TIMELINE_READY` (triggered once the timeline canvas has been mounted)
- `TimelineEventType.TIMELINE_SCROLL` (triggered on horizontal timeline scroll; `event.data.scrollPercent` is 0–100)
- `TimelineEventType.TIMELINE_ZOOM` (triggered on zoom change; `event.data.zoomPercent` is 0–100)
- `TimelineEventType.TIMELINE_SLOT_SCROLL` (triggered on vertical scroll of a slot — only `MAIN` scrolls vertically; `event.data` carries `slot`, `scrollPercent`, and `deltaPercent`)
- `TimelineEventType.TIMELINE_TIMECODE_CLICK` (triggered when the timecode axis is clicked; carries `seconds`, `timecode`, `mouseEvent`, `pointerPosition`)
- `TimelineEventType.TIMELINE_TIMECODE_MOUSE_MOVE` (triggered on mouse move over the timecode axis)
- `TimelineEventType.TIMELINE_SCRUBBER_MOVE` (triggered as the hover scrubber moves; `event.data.snapped` indicates whether it snapped to the playhead)
- `TimelineEventType.TIMELINE_PLAYHEAD_MOVE` (triggered as the playhead moves)

```ts
import {TimelineEventType} from '@byomakase/omakase-player';

timeline.onEvent$.subscribe((event) => {
  if (event.type === TimelineEventType.TIMELINE_SCROLL) {
    console.log(event.data.scrollPercent);
  }
  if (event.type === TimelineEventType.TIMELINE_SLOT_SCROLL) {
    console.log(event.data.slot, event.data.scrollPercent, event.data.deltaPercent);
  }
});
```

Each slot also exposes its own `onEvent$` (see [Slots](#slots)), carrying `TimelineSlotEventType.TIMELINE_SLOT_RESIZE` (effective/content height may have changed) and `TimelineSlotEventType.TIMELINE_SLOT_SCROLL` (vertical scroll, `MAIN` only — mirrors the slot's `scroll.onScroll$`).

## Marker List

Marker list is initialized by defining a div placeholder and creating a `MarkerList` instance with optional configuration.
The marker list web component will be added into an html element with id defined in `markerListHTMLElementId`. If this parameter is not provided, it will default to `omakase-marker-list`. Following code will instantiate an empty marker list.

```html
<div id="marker-list"></div>
```

```javascript
import {MarkerList} from '@byomakase/omakase-player';

const markerList = new MarkerList(
  {
    markerListHTMLElementId: 'marker-list',
  },
  omakasePlayer
);
```

### Loading markers from a VTT file

A marker list can be loaded from a VTT file by providing a URL via the `markerTrack` property. This action will automatically register marker track in the track repository and load timed items from assigned VTT file.
The `loadingHTMLElementId` parameter can specify HTML content to render while the file is loading.

```html
<div id="marker-list"></div>
<template id="loading-template">
  <!-- content to render while the VTT file is loading -->
</template>
```

```javascript
const markerList = new MarkerList(
  {
    markerListHTMLElementId: 'marker-list',
    loadingHTMLElementId: 'loading-template',
    markerTrack: {source: UrlSource.of('https://example.com/data/markers.vtt')},
  },
  omakasePlayer
);
```

### Linking to marker tracks

Marker list can be linked to one or more `MarkerTrack` instances. Markers are managed on the track itself (see [Marker Track](#marker-track) above) — the marker list only reflects it, staying in sync whenever markers are added, updated, or removed on the linked track(s).

```javascript
import {MarkerList, TrackSource} from '@byomakase/omakase-player';

const markerList = new MarkerList(
  {
    markerListHTMLElementId: 'marker-list',
    markerTrack: [{source: TrackSource.fromTrack(markerTrack1)}, {source: TrackSource.fromTrack(markerTrack2)}],
  },
  omakasePlayer
);
```

### Thumbnails

A thumbnail track can be provided using the `thumbnailTrack` property. If provided, it will be used to automatically set the thumbnail to the closest VTT cue based on the marker start time.

```javascript
const markerList = new MarkerList(
  {
    markerListHTMLElementId: 'marker-list',
    thumbnailTrack: {source: UrlSource.of('https://example.com/data/thumbnails.vtt')},
  },
  omakasePlayer
);
```

### Styling and templating

Marker list HTML and style can be customised by passing a css file url and template element ids.

A template for the marker list row can include slots to render data or trigger actions. The following slots are predefined:

- `color` (from marker style)
- `thumbnail` (from `thumbnailTrack`, if provided)
- `name` (marker `label` property)
- `track` (label of the linked marker track, if applicable)
- `start` (start time from marker `temporal`)
- `end` (end time from marker `temporal`)
- `duration` (difference between `end` and `start`)
- `remove` (triggers marker removal)

Beside predefined slots, dynamic slots can be used to display custom data or trigger custom actions. Custom data slots must be prefixed with `data-` and custom action slots must be prefixed with `action-`.

The parameter `styleUrl` can be an array to provide multiple css files.

```html
<template id="row-template">
  <div slot="color"></div>
  <div slot="name"></div>
  <div slot="start"></div>
  <div slot="end"></div>
  <div class="actions">
    <span slot="action-edit"></span>
    <span slot="remove"></span>
  </div>
</template>

<template id="header-template">
  <!-- header content -->
</template>

<template id="empty-template">
  <!-- content to render if marker list is empty -->
</template>
```

```javascript
const markerList = new MarkerList(
  {
    markerListHTMLElementId: 'marker-list',
    templateHTMLElementId: 'row-template',
    headerHTMLElementId: 'header-template',
    emptyHTMLElementId: 'empty-template',
    styleUrl: './style.css',
  },
  omakasePlayer
);
```

For detailed styling variables please check [Marker List](https://api.player.byomakase.org/documents/OmakasePlayer.STYLING.html#marker-list) in Styling documentation.

### Events

All events are emitted via the `onEvent$` observable. The following event types are available:

- `MarkerListEventType.MARKER_LIST_ITEM_CLICK` (triggered when the marker row is clicked)
- `MarkerListEventType.MARKER_LIST_ITEM_ACTION` (triggered when a custom element provided with an `action-<name>` slot is clicked)
- `MarkerListEventType.MARKER_LIST_ITEM_DELETE` (triggered when a marker is deleted via the `remove` slot)
- `MarkerListEventType.MARKER_LIST_TRACKS_LOADED` (triggered when all tracks supplied to the `markerTrack` config parameter are loaded)
- `MarkerListEventType.MARKER_LIST_ITEM_MOUSE_ENTER`
- `MarkerListEventType.MARKER_LIST_ITEM_MOUSE_LEAVE`

Some usage examples are shown below:

```javascript
import {MarkerListEventType} from '@byomakase/omakase-player';

markerList.onEvent$.subscribe((event) => {
  if (event.type === MarkerListEventType.MARKER_LIST_ITEM_CLICK) {
    console.log(event.data.item);
  }
  if (event.type === MarkerListEventType.MARKER_LIST_ITEM_ACTION) {
    console.log(event.data.action, event.data.item);
  }
});
```

### Destroy

Marker list can be destroyed with the `destroy()` method. This cleans up the marker list resources and removes it from the DOM.

## VU Meter

The `VuMeter` class provides a self-contained audio level visualization component. It connects to an audio source — either automatically from the player's peak processor or manually via `setSource` — and renders live dB levels as a bar or LED meter.

### Example 1 — automatic source via constructor

Pass `player` and `audioType` directly. The VU Meter creates and manages the peak processor internally.

```html
<div id="omakase-vu-meter"></div>
```

```javascript
import {VuMeter, PlayerAudioType} from '@byomakase/omakase-player';

const vuMeter = new VuMeter({
  player: omakasePlayer,
  audioType: PlayerAudioType.MAIN,
  config: {
    htmlElementId: 'omakase-vu-meter',
  },
});
```

### Example 2 — manual source via `setSource`

Construct the VU Meter with only layout config, then wire it to a `PeakProcessorAudioLevelSource` created from a sidecar audio track.

```html
<div id="omakase-vu-meter"></div>
```

```javascript
import {VuMeter, PeakProcessorAudioLevelSource, PlayerAudioType} from '@byomakase/omakase-player';

const vuMeter = new VuMeter({
  config: {
    htmlElementId: 'omakase-vu-meter',
    channels: 2,
  },
});

// Create a source from a sidecar audio track
const source = new PeakProcessorAudioLevelSource(omakasePlayer, PlayerAudioType.SIDECAR, 'sidecarTrackId');
vuMeter.setSource(source);
```

### Configuration

`VuMeter` is constructed with a `VuMeterArgs` object.

| Field       | Type                     | Description                                                                                                                                   |
| ----------- | ------------------------ | --------------------------------------------------------------------------------------------------------------------------------------------- |
| `player`    | `OmakasePlayerApi`       | Player instance. Required when using `audioType` or `trackId`.                                                                                |
| `audioType` | `PlayerAudioType`        | Audio source type for peak-processor-based sources: `MAIN` or `OUTPUT`. Not needed when using `trackId`.                                      |
| `trackId`   | `string`                 | ID of a sidecar audio track or observation track. When provided with `player`, the source type is resolved automatically from the track type. |
| `source`    | `AudioLevelSourceApi`    | Pre-built audio level source. Takes precedence over `player`/`audioType`/`trackId`.                                                           |
| `config`    | `Partial<VuMeterConfig>` | VU Meter configuration. See `VuMeterConfig` below.                                                                                            |

#### `VuMeterConfig`

| Field               | Type                    | Default                         | Description                                                                                                 |
| ------------------- | ----------------------- | ------------------------------- | ----------------------------------------------------------------------------------------------------------- |
| `htmlElementId`     | `string`                | `'omakase-vu-meter'`            | ID of the HTML element where the VU Meter will be rendered.                                                 |
| `htmlElement`       | `HTMLElement`           | —                               | HTML element to render into. Takes precedence over `htmlElementId` when both are provided.                  |
| `theme`             | `VuMeterTheme`          | `DEFAULT`                       | `DEFAULT` renders filled bars; `LED` renders a column of discrete segments.                                 |
| `orientation`       | `VuMeterOrientation`    | `VERTICAL`                      | `VERTICAL` stacks bars top-to-bottom; `HORIZONTAL` renders bars left-to-right.                              |
| `channels`          | `number`                | auto-detected                   | Number of channels to display (Can be 1, 2 or 6). Auto-detected from the source when omitted.               |
| `scale`             | `VuMeterScale`          | `DEFAULT`                       | `DEFAULT`: As configured with other parameters. `NORDIC`: fixed 3 dB steps, 12 dB offset. `NONE`: no scale. |
| `rangeMinDb`        | `number`                | `-54`                           | Minimum dB value at the bottom of the scale.                                                                |
| `scaleStepDb`       | `number`                | `6`                             | Interval in dB between scale tick marks. Ignored when `scale` is `NORDIC`.                                  |
| `scaleOffsetDb`     | `number`                | `0`                             | Offset applied to all scale label values. Ignored when `scale` is `NORDIC`.                                 |
| `levelHoldDuration` | `number`                | `0`                             | Milliseconds the peak-hold indicator stays visible after a peak. `0` disables peak hold.                    |
| `labels`            | `string[]`              | `['L','R','C','LFE','Ls','Rs']` | Channel labels displayed beneath each bar.                                                                  |
| `style`             | `Partial<VuMeterStyle>` | See below                       | Visual style overrides. See `VuMeterStyle`.                                                                 |

#### `VuMeterStyle`

| Field               | Type             | Default       | Description                                                            |
| ------------------- | ---------------- | ------------- | ---------------------------------------------------------------------- |
| `showScaleLabels`   | `boolean`        | `true`        | Show dB value labels along the scale.                                  |
| `showScaleMarks`    | `boolean`        | `true`        | Show tick marks along the scale.                                       |
| `showChannelLabels` | `boolean`        | `true`        | Show channel labels beneath each bar.                                  |
| `levelColors`       | `VuMeterColor[]` | See below     | Color thresholds for the level bar. Applied in ascending `maxValueDb`. |
| `levelBackground`   | `string`         | `transparent` | Background color of the level bar or LED segments.                     |

Default `levelColors` for `Default` theme:

| `maxValueDb` | `color`   | `holdColor` |
| ------------ | --------- | ----------- |
| `-18`        | `#008800` | `#00880088` |
| `-12`        | `#04E400` | `#04E40088` |
| `-9`         | `#F27100` | `#F2710088` |
| `0`          | `#BB0000` | `#BB000088` |

Default `levelColors` for `LED` theme:

| `maxValueDb` | `color`   | `holdColor` |
| ------------ | --------- | ----------- |
| `-15`        | `#04E400` | `#04E40088` |
| `-9`         | `#F27100` | `#F2710088` |
| `0`          | `#BB0000` | `#BB000088` |

#### `VuMeterColor`

| Field        | Description                            | Type     |
| ------------ | -------------------------------------- | -------- |
| `maxValueDb` | Upper bound of the color segment in dB | `number` |
| `color`      | Level segment color                    | `string` |
| `holdColor`  | Hold level segment color               | `string` |

### Styling

For detailed styling variables please check [VU Meter](https://api.player.byomakase.org/documents/OmakasePlayer.STYLING.html#vu-meter) in Styling documentation.

## Development

Player build & build watch

```bash
npm install ci
npm run dev
```

## Production build

```bash
npm install ci
npm run prod
```

Production artifacts that need to be published to NPM are created in `/dist` folder

## Known limitations

- Safari browser doesn't support Main audio routing and Main audio VU Meter for HLS streams.
